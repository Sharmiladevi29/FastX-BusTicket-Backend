package com.fastx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastXapibackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
