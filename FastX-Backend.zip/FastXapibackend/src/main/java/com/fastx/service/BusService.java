package com.fastx.service;

import com.fastx.model.Bus;

import java.util.List;

public interface BusService {
    Bus addBus(Bus bus);
    List<Bus> getAllBuses();
    Bus getBusById(Long id);
    void deleteBus(Long id);
    Bus updateBus(Long id, Bus updatedBus);
}
