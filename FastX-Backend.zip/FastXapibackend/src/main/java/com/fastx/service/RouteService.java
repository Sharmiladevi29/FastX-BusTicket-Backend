package com.fastx.service;

import com.fastx.model.Route;
import java.util.List;

public interface RouteService {
    Route createRoute(Route route);
    List<Route> getAllRoutes();
    Route getRouteById(Long id);
    Route updateRoute(Long id, Route route);
    void deleteRoute(Long id);
}
