package com.fastx.service;

import com.fastx.model.Booking;

import java.security.Principal;
import java.util.List;

public interface BookingService {
    Booking bookSeat(Long scheduleId, int seatNumber, Principal principal);
    List<Integer> getAvailableSeats(Long scheduleId);
    List<Booking> getUserBookings(String email);
}
