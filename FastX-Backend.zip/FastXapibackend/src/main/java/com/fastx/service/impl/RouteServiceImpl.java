package com.fastx.service.impl;

import com.fastx.model.Route;
import com.fastx.repository.RouteRepository;
import com.fastx.service.RouteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RouteServiceImpl implements RouteService {

    private final RouteRepository routeRepository;

    @Override
    public Route createRoute(Route route) {
        return routeRepository.save(route);
    }

    @Override
    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    @Override
    public Route getRouteById(Long id) {
        return routeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Route not found"));
    }

    @Override
    public Route updateRoute(Long id, Route route) {
        Route existing = getRouteById(id);
        existing.setOrigin(route.getOrigin());
        existing.setDestination(route.getDestination());
        existing.setDistanceInKm(route.getDistanceInKm());
        existing.setTravelTime(route.getTravelTime());
        return routeRepository.save(existing);
    }

    @Override
    public void deleteRoute(Long id) {
        routeRepository.deleteById(id);
    }
}
