package com.fastx.service;

import com.fastx.model.Schedule;

import java.time.LocalDate;
import java.util.List;

public interface ScheduleService {
    Schedule addSchedule(Schedule schedule);
    List<Schedule> getAllSchedules();
    Schedule getScheduleById(Long id);
    List<Schedule> getSchedulesByDate(LocalDate date);
    Schedule updateSchedule(Long id, Schedule schedule);
    void deleteSchedule(Long id);
}
