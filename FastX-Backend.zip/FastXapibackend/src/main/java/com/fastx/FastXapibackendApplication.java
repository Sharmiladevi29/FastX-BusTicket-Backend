package com.fastx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FastXapibackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FastXapibackendApplication.class, args);
		System.out.println("FASTXAPI IS RUNNING SUCCESSFULLY...");
	}

}
