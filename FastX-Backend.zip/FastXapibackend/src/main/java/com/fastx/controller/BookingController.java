package com.fastx.controller;

import com.fastx.model.Booking;
import com.fastx.service.BookingService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@SecurityRequirement(name = "bearerAuth") // Enable JWT in Swagger UI
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    // 👤 USER & ADMIN can book a seat
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @PostMapping("/{scheduleId}/book")
    public ResponseEntity<Booking> bookSeat(@PathVariable Long scheduleId,
                                            @RequestParam int seatNumber,
                                            Principal principal) {
        return new ResponseEntity<>(bookingService.bookSeat(scheduleId, seatNumber, principal), HttpStatus.CREATED);
    }

    // 👤 USER & ADMIN can view available seats
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/{scheduleId}/available-seats")
    public ResponseEntity<List<Integer>> getAvailableSeats(@PathVariable Long scheduleId) {
        return ResponseEntity.ok(bookingService.getAvailableSeats(scheduleId));
    }

    // 👤 Only the logged-in user can see their bookings
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @GetMapping("/my")
    public ResponseEntity<List<Booking>> getUserBookings(Principal principal) {
        return ResponseEntity.ok(bookingService.getUserBookings(principal.getName()));
    }
}
